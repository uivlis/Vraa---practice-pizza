package Auxiliary;

import java.util.List;

public class SliceComputation {

	private int nrRows;
	private int nrColumns;
	private int minIntregients;
	private int maxCells;

	private char[][] pizza;

	private long[] ingredients;

	public SliceComputation(int[] params, char[][] pizza, List<String> outputList) {
		nrRows = params[0];
		nrColumns = params[1];
		minIntregients = params[2];
		maxCells = params[3];

		this.pizza = pizza;

		ingredients = countIngredients();

		outputList.add("Tomatoes: " + ingredients[0]);
		outputList.add("Mushrooms: " + ingredients[1]);
		outputList.add("Min " + minIntregients + " of each per slice");
		outputList.add("Max " + maxCells + " cells per slice");

//		computeSlices();
	}

	private long[] countIngredients() {

		long[] ingredients = { 0, 0 };

		for (int i = 0; i < nrRows; i++) {
			for (int j = 0; j < nrColumns; j++) {
				if (pizza[i][j] == 'T') {
					ingredients[0]++;
				} else
					ingredients[1]++;
			}
		}

		return ingredients;
	}

//	private boolean isSliceOK(int xS, int yS, int xF, int yF) {
//		int countTomatoes = 0;
//		int countMushrooms = 0;
//		for (int i = xS; i < xF; i++) {
//			for (int j = yS; j < yF; j++) {
//				if (pizza[i][j] == 'T')
//					countTomatoes++;
//				else
//					countMushrooms++;
//			}
//		}
//
//		if ((countTomatoes == minIntregients) && (countMushrooms == minIntregients))
//			return true;
//		return false;
//	}
//
//	private void computeSlices() {
//		if(isSliceOK(0, 0, 1, 1)){
//			
//		}
//	}
}
