package Auxiliary;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileProcessor {

	private int[] fileParameters;
	private String[] pizzaStringArray;
	private char[][] pizza;
	
	public void processFile(String fileName) {
		try (BufferedReader br = new BufferedReader(new FileReader("InputFiles\\" + fileName))) {

			fileParameters = findFileParameters(br.readLine());

			pizzaStringArray = new String[fileParameters[0]];
			
			pizza = new char[fileParameters[0]][fileParameters[1]];

			String currentLine;
			int counter = 0;
			while ((currentLine = br.readLine()) != null) {
				pizzaStringArray[counter] = currentLine;
				counter++;
			}

		} catch (IOException e) {
			System.out.println("Exception caught while trying to read from file " + fileName + " !");
		}
		
		createPizzaCharMatrix(pizzaStringArray);
		
	}

	private int[] findFileParameters(String parametersLine) {
		int[] params = { 0, 0, 0, 0 };

		char[] line = parametersLine.toCharArray();
		int i = 0;
		for (char c : line) {
			if (c != ' ') {
				params[i] *= 10; 
				params[i] += Character.getNumericValue(c);
			}else{
				i++;
			}
		}

		return params;
	}
	
	private void createPizzaCharMatrix(String[] sPizza){
		for (int i = 0; i < fileParameters[0]; i++) {
			pizza[i] = sPizza[i].toCharArray();
		}
	}

	public int[] getParameters() {
		return fileParameters;
	}
	
	public char[][] getPizza() {
		return pizza;
	}
		
}
