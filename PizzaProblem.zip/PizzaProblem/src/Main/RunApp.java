package Main;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import Auxiliary.FileProcessor;
import Auxiliary.SliceComputation;

public class RunApp {

	private static final String fileName = "medium.in";

	public static void main(String[] args) {

		FileProcessor fp = new FileProcessor();
		fp.processFile(fileName);

		List<String> outputList = new ArrayList<String>();
		
		outputList.add("Data from file " + fileName + "\n------------");
		new SliceComputation(fp.getParameters(), fp.getPizza(), outputList);
		
		writeToFile(outputList);

	}
	
	private static void writeToFile(List<String> lines) {
		
		Path file = Paths.get("OutputFiles\\solution.out");
		try {
			Files.write(file, lines, Charset.forName("UTF-8"));
		} catch (IOException e) {
			System.out.println("Exception caught when writing in output file !");
		}
		
		System.out.println("check the output file");
	}

}
